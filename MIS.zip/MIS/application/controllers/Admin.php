<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Admin extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        is_logged_in();
    }

    public function index()
    {
        $data['title'] = 'Dashboard';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('admin/index', $data);
        $this->load->view('templates/footer');
    }


    public function role()
    {
        $data['title'] = 'Role';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

        $data['role'] = $this->db->get('user_role')->result_array();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('admin/role', $data);
        $this->load->view('templates/footer');
    }


    public function roleAccess($role_id)
    {
        $data['title'] = 'Role Access';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

        $data['role'] = $this->db->get_where('user_role', ['id' => $role_id])->row_array();

        $this->db->where('id !=', 1);
        $data['menu'] = $this->db->get('user_menu')->result_array();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('admin/role-access', $data);
        $this->load->view('templates/footer');
    }


    public function changeAccess()
    {
        $menu_id = $this->input->post('menuId');
        $role_id = $this->input->post('roleId');

        $data = [
            'role_id' => $role_id,
            'menu_id' => $menu_id
        ];

        $result = $this->db->get_where('user_access_menu', $data);

        if ($result->num_rows() < 1) {
            $this->db->insert('user_access_menu', $data);
        } else {
            $this->db->delete('user_access_menu', $data);
        }

        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Access Changed!</div>');
    }


    public function usermenu()
    {
        $data['title'] = 'User Menu';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

        $data['usermenu'] = $this->db->get('user')->result_array();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('admin/usermenu', $data);
        $this->load->view('templates/footer');
    }


    public function usermenuaccess()
    {
        $data['title'] = 'User Menu Access';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

        $data['usermenu'] = $this->db->get('user')->result_array();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('admin/usermenu-access', $data);
        $this->load->view('templates/footer');
    }



    public function change_status($userId)
    {
        // Logic to toggle the user's active status
        // This is just a basic example; you should implement your own logic
        $user = $this->user_model->getUserById($userId); // Replace with your model method to get user data
        $newStatus = $user['is_active'] ? 0 : 1; // Toggle the status

        // Update the user's status in the database
        $this->user_model->updateUserStatus($userId, $newStatus); // Replace with your model method to update user status

        // Redirect back to the user list or wherever you want
        redirect('admin/userlist');
    }

    public function useredit($userId) {
        $data['title'] = 'User Edit';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

        $data['usermenu'] = $this->db->get('user')->result_array();

        // Load the model for user data
        $this->load->model('User_model');
    
        // Get user details based on $userId
        $data['user'] = $this->User_model->getUserById($userId);
    
        // Load the view for editing user information
        
        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('admin/edit_user', $data);
        $this->load->view('templates/footer');
    }
    
    // In your model (e.g., User_model.php)
    public function getUserById($userId) {
        // Query the database to get user details based on $userId
        $query = $this->db->get_where('users', array('id' => $userId));
        return $query->row_array();
    }
    
    public function update_user() {
        // Get form data
        $userId = $this->input->post('user_id');
        $data = array(
            'name' => $this->input->post('name'),
            'email' => $this->input->post('email'),
            'role_id' => $this->input->post('role_id'),
            'is_active' => $this->input->post('is_active')
            // Add other fields as needed
        );

        // Load the model
        $this->load->model('User_model');

        // Update user information in the database
        $this->User_model->updateUser($userId, $data);

        // Redirect or load a view as needed
        redirect('admin/usermenu'); // Redirect to the user list page, for example
    }

    public function add_user() {
        // Get form data
        $data = array(
            'name' => $this->input->post('name'),
            'email' => $this->input->post('email'),
            'role_id' => $this->input->post('role_id'),
            'is_active' => $this->input->post('is_active')
            // Add other fields as needed
        );

        // Load the model
        $this->load->model('User_model');

        // Insert new user into the database
        $this->User_model->addUser($data);

        // Redirect or load a view as needed
        redirect('admin/usermenu'); // Redirect to the user list page, for example
    }

    public function delete_user($userId) {
        // Load the model
        $this->load->model('User_model');

        // Delete the user from the database
        $this->User_model->deleteUser($userId);

        // Redirect or load a view as needed
        redirect('admin/usermenu'); // Redirect to the user list page, for example
    }




}
