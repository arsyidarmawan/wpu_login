<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>



    <div class="row">
        <div class="col-lg-12">
            <?= form_error('menu', '<div class="alert alert-danger" role="alert">', '</div>'); ?>

            <?= $this->session->flashdata('message'); ?>

            <a href="" class="btn btn-primary mb-3" data-toggle="modal" data-target="#addUserModal">Add New User</a>

            <table class="table table-hover">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Name</th>
                        <th scope="col">Email</th>
                        <th scope="col">Role ID</th>
                        <th scope="col">Active</th>
                        <th scope="col">Date Created</th>
                        <th scope="col">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $i = 1; ?>
                    <?php foreach ($usermenu as $um) : ?>
                    <tr>
                        <th scope="row"><?= $i; ?></th>
                        <td><?= $um['name']; ?></td>
                        <td><?= $um['email']; ?></td>
                        <td><?= $um['role_id']; ?></td>
                        <td><?= $um['is_active']; ?>
                        </td>
                        <td><?= $um['date_created']; ?></td>
                        <td>
                            <a href="<?= base_url('admin/useredit/') . $um['id']; ?>" class="badge badge-success" data-toggle="modal" data-target="#editUserModal">edit</a>
                            <a id="deleteUserBtn<?= $um['id']; ?>" href="#" class="badge badge-danger" data-toggle="modal" data-target="#deleteUserModal<?= $um['id']; ?>">delete</a>
                        </td>
                    </tr>

                    
                    <?php $i++; ?>
                    <?php endforeach; ?>
                </tbody>
            </table>


        </div>
    </div>



</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->

<!-- Modal -->

<!-- Modal -->
<?php foreach ($usermenu as $um) : ?>
<div class="modal fade" id="editUserModal" tabindex="-1" role="dialog" aria-labelledby="editUserModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editUserModalLabel">Edit User Information</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="<?= base_url('admin/update_user'); ?>" method="post">
                <div class="modal-body">
                    <input type="hidden" name="user_id" value="<?= $um['id']; ?>">
                    <div class="form-group">
                        <label for="name">Name:</label>
                        <input type="text" class="form-control" id="name" name="name" value="<?= $um['name']; ?>" placeholder="User name">
                    </div>
                    <div class="form-group">
                        <label for="email">Email:</label>
                        <input type="email" class="form-control" id="email" name="email" value="<?= $um['email']; ?>" placeholder="User email">
                    </div>
                    <div class="form-group">
                        <label for="role_id">Role ID:</label>
                        <input type="text" class="form-control" id="role_id" name="role_id" value="<?= $um['role_id']; ?>" placeholder="Role ID">
                    </div>
                    <div class="form-group">
                        <label for="is_active">Active:</label>
                        <input type="text" class="form-control" id="is_active" name="is_active" value="<?= $um['is_active']; ?>" placeholder="Active status">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save Changes</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endforeach; ?>

<!-- Add User Modal -->
<div class="modal fade" id="addUserModal" tabindex="-1" role="dialog" aria-labelledby="addUserModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addUserModalLabel">Add New User</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="<?= base_url('admin/add_user'); ?>" method="post">
                <div class="modal-body">
                    <div class="form-group">
                        <label for="name">Name:</label>
                        <input type="text" class="form-control" id="name" name="name" placeholder="User name">
                    </div>
                    <div class="form-group">
                        <label for="email">Email:</label>
                        <input type="email" class="form-control" id="email" name="email" placeholder="User email">
                    </div>
                    <div class="form-group">
                        <label for="role_id">Role ID:</label>
                        <input type="text" class="form-control" id="role_id" name="role_id" placeholder="Role ID">
                    </div>
                    <div class="form-group">
                        <label for="is_active">Active:</label>
                        <input type="text" class="form-control" id="is_active" name="is_active" placeholder="Active status">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Add User</button>
                </div>
            </form>
        </div>
    </div>
</div>


<!-- Delete User Confirmation Modal -->
<div class="modal fade" id="deleteUserModal" tabindex="-1" role="dialog" aria-labelledby="deleteUserModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="deleteUserModalLabel">Confirm Deletion</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                Are you sure you want to delete this user?
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                <a href="#" id="confirmDeleteUser" class="btn btn-danger">Delete</a>
            </div>
        </div>
    </div>
</div>

<!-- Add JavaScript to handle deletion confirmation -->
<script>
    // Function to handle user deletion
    function deleteUser(userId) {
        // You may want to show a confirmation dialog here
        var confirmed = confirm("Are you sure you want to delete this user?");

        if (confirmed) {
            // Redirect to the delete_user method with the user's ID
            window.location.href = '<?= base_url("admin/delete_user/") ?>' + userId;
        }
    }

    // Attach click event listeners to delete buttons
    <?php foreach ($usermenu as $um) : ?>
        document.getElementById('deleteUserBtn<?= $um['id']; ?>').addEventListener('click', function() {
            deleteUser(<?= $um['id']; ?>);
        });
    <?php endforeach; ?>
</script>

