<?php 
defined('BASEPATH') or exit('No direct script access allowed');

// application/models/Your_model.php
class Oasa_model extends CI_Model {
    public function get_data_with_limit($limit, $offset, $search = '')
    {
        $this->db->limit($limit, $offset);

        if (!empty($search)) {
            $this->db->like('CARDNO', $search);
            // Add more conditions for other columns if needed
        }

        return $this->db->get('blok_all')->result_array();
    }

    public function count_all_data($search = '')
    {
        if (!empty($search)) {
            $this->db->like('CARDNO', $search);
            // Add more conditions for other columns if needed
        }

        return $this->db->count_all_results('blok_all');
    }
}

