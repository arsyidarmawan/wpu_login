<?php 
defined('BASEPATH') or exit('No direct script access allowed');

// application/models/User_model.php

class User_model extends CI_Model {

    public function getUserById($userId) {
        // Retrieve user details based on $userId
        $query = $this->db->get_where('user', array('id' => $userId));
        return $query->row_array();
    }

    public function updateUser($userId, $data) {
        // Update user information in the database
        $this->db->where('id', $userId);
        $this->db->update('user', $data);
    }
    public function addUser($data) {
        // Insert new user into the database
        $this->db->insert('user', $data);
    }

    public function deleteUser($userId) {
        // Delete user from the database
        $this->db->where('id', $userId);
        $this->db->delete('user');
    }
}
